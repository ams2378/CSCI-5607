//File parsing example using filestream >> operator

#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstring>
#include "datastructure.h"

using namespace std;

void readInputFile (string fileName, Scene& scene, Setup& setup); 
